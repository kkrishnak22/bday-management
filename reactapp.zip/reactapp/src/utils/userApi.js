import { BaseUrl } from "./authApi";

export const BASE_URL = BaseUrl;
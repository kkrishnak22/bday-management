package com.examly.springapp.controller;
import org.springframework.web.bind.annotation.*;

// @RestController
// @RequestMapping("/")

// @CrossOrigin(origins = "*", allowedHeaders)
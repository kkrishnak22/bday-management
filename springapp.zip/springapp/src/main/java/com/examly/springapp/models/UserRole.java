package com.examly.springapp.models;
// import lombok.AllArgsConstructor;
// import lombok.RequiredArgsConstructor;
// @RequiredArgsConstructor
public enum UserRole {
    
    USER,
    ADMIN
}